import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Store} from '../store.mjs';
test('activación, límite, revocación, extensión, reset y cuota',()=>{
  const s=new Store(':memory:');
  try {
    const l=s.create({name:'Prueba',minutes:60,maxDevices:1});
    const a=s.activate(l.code,'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa');
    assert.equal(s.authorize(a.token).id,l.id);
    assert.throws(()=>s.activate(l.code,'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'),/Límite/);
    assert.throws(()=>s.authorize('falso'),/Sesión/);
    assert.throws(()=>s.activate('MP_falso','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'),/Licencia/);
    assert.equal(s.db.prepare('SELECT key_hash FROM licenses').get().key_hash.includes(l.code),false);
    s.consume(l.id,1);assert.throws(()=>s.consume(l.id,1),/Límite diario/);
    s.update({id:l.id,action:'revoke'});assert.throws(()=>s.authorize(a.token),/revocada/);
    s.update({id:l.id,action:'extend',minutes:10});assert.equal(s.authorize(a.token).id,l.id);
    s.update({id:l.id,action:'reset-devices'});assert.throws(()=>s.authorize(a.token),/Sesión/);
    const b=s.activate(l.code,'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb');assert.equal(s.authorize(b.token).id,l.id);
    s.db.prepare('UPDATE licenses SET exp=0 WHERE id=?').run(l.id);assert.throws(()=>s.authorize(b.token),/vencida/);
    assert.throws(()=>s.activate(l.code,'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'),/vencida/);
  } finally{s.db.close();}
});
test('sesión expirada y entradas inválidas',()=>{
  const s=new Store(':memory:');
  try {
    assert.throws(()=>s.create({name:'x',minutes:-1}),/inválidos/);
    const l=s.create({name:'x',minutes:1});
    const a=s.activate(l.code,'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa');
    s.db.exec('UPDATE sessions SET exp=0');assert.throws(()=>s.authorize(a.token),/vencida/);
    assert.throws(()=>s.update({id:l.id,action:'extend',minutes:NaN}),/inválida/);
  } finally{s.db.close();}
});
