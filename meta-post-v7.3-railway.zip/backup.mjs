import {DatabaseSync,backup} from 'node:sqlite';
const path=process.env.DB_PATH||'./data/licenses.sqlite';
const db=new DatabaseSync(path,{readOnly:true});
try {await backup(db,'/app/data/backup.sqlite');console.log('Copia consistente creada: /app/data/backup.sqlite');}
finally {db.close();}
