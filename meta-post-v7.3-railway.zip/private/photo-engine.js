async function createExtremeVariation(sourceImage, index = 0, total = 1) {
    const canvas = document.createElement('canvas');
    
    // ════════════════════════════════════════════════════════════
    // CAPA 1: SISTEMA DE 50 ETAPAS DE RECORTE (75% a 89%)
    // ════════════════════════════════════════════════════════════
    let stage = index % 50;

    const rangos = [
        [0.75, 0.89], [0.76, 0.88], [0.77, 0.87], [0.78, 0.86], [0.75, 0.88],
        [0.76, 0.87], [0.77, 0.86], [0.78, 0.85], [0.75, 0.87], [0.76, 0.86],
        [0.77, 0.85], [0.78, 0.84], [0.75, 0.86], [0.76, 0.85], [0.77, 0.84],
        [0.78, 0.83], [0.75, 0.85], [0.76, 0.84], [0.77, 0.83], [0.78, 0.82],
        [0.75, 0.84], [0.76, 0.83], [0.77, 0.82], [0.78, 0.81], [0.75, 0.83],
        [0.76, 0.82], [0.77, 0.81], [0.78, 0.80], [0.75, 0.82], [0.76, 0.81],
        [0.77, 0.80], [0.78, 0.79], [0.75, 0.81], [0.76, 0.80], [0.77, 0.79],
        [0.78, 0.89], [0.75, 0.80], [0.76, 0.79], [0.77, 0.78], [0.78, 0.88],
        [0.75, 0.79], [0.76, 0.78], [0.77, 0.89], [0.78, 0.87], [0.75, 0.78],
        [0.76, 0.77], [0.77, 0.88], [0.76, 0.89], [0.75, 0.77], [0.75, 0.76]
    ];

    const [baseMin, baseMax] = rangos[stage];
    const variacion = (Math.random() - 0.5) * 0.02; 
    
    const minKeep = Math.max(0.75, baseMin + variacion);
    const maxKeep = Math.min(0.89, baseMax + variacion);
    const scale = minKeep + (Math.random() * (maxKeep - minKeep));
    
    // Dimensiones y coordenadas dinámicas del recorte
    const drawW = sourceImage.width * scale;
    const drawH = sourceImage.height * scale;
    const startX = (sourceImage.width - drawW) * Math.random();
    const startY = (sourceImage.height - drawH) * Math.random();
    
    canvas.width = drawW;
    canvas.height = drawH;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    // ════════════════════════════════════════════════════════════
    // CAPA 2 a 5: DISTORSIÓN GEOMÉTRICA INVISIBLE Y COLORIMETRÍA
    // ════════════════════════════════════════════════════════════
    ctx.save();
    // Escala asimétrica: proporciones matemáticas cambian sutilmente
    const scaleX = 1 + (Math.random() * 0.02 - 0.01); 
    const scaleY = 1 + (Math.random() * 0.02 - 0.01); 
    const angle = (Math.random() * 0.4 - 0.2) * (Math.PI / 180);

    ctx.translate(drawW / 2, drawH / 2);
    ctx.rotate(angle);
    ctx.scale(scaleX, scaleY);

    // Mutación de luz y color nativa (Altísima velocidad)
    const b = Math.floor(Math.random() * 6 + 97);  // Brillo 97-103%
    const c = Math.floor(Math.random() * 6 + 97);  // Contraste 97-103%
    const s = Math.floor(Math.random() * 10 + 95); // Saturación 95-105%
    const h = Math.random() * 2 - 1;               // Hue sutil
    
    ctx.filter = `brightness(${b}%) contrast(${c}%) saturate(${s}%) hue-rotate(${h}deg)`;

    // Imprimimos la foto recortada en el lienzo transformado
    ctx.drawImage(sourceImage, startX, startY, drawW, drawH, -drawW / 2, -drawH / 2, drawW, drawH);
    ctx.restore();

    // ════════════════════════════════════════════════════════════
    // CAPA 6 a 106: LAS 100 CAPAS DE RUIDO ESTOCÁSTICO
    // ════════════════════════════════════════════════════════════
    // Inyectamos 100 bloques microscópicos para destruir el hash original.
    ctx.globalCompositeOperation = 'overlay';
    for (let i = 0; i < 100; i++) {
        ctx.fillStyle = `rgba(${Math.floor(Math.random()*255)}, ${Math.floor(Math.random()*255)}, ${Math.floor(Math.random()*255)}, 0.003)`;
        
        const rectX = Math.random() * drawW;
        const rectY = Math.random() * drawH;
        const rectSize = 1 + Math.random() * 3;
        
        ctx.fillRect(rectX, rectY, rectSize, rectSize);
    }

    // Baño de gradiente térmico (destruye los perfiles de color estáticos)
    const grad = ctx.createLinearGradient(0, 0, drawW, drawH);
    grad.addColorStop(0, `rgba(${Math.random()*255},${Math.random()*255},${Math.random()*255},0.01)`);
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, drawW, drawH);
    
    ctx.globalCompositeOperation = 'source-over';

    // ════════════════════════════════════════════════════════════
    // CAPA FINAL: COMPRESIÓN MUTANTE DE SALIDA
    // ════════════════════════════════════════════════════════════
    // 50% probabilidad de WEBP o JPEG. Calidad fluctuante.
    const useWebp = Math.random() > 0.5; 
    const mime = useWebp ? 'image/webp' : 'image/jpeg';
    const quality = 0.86 + (Math.random() * 0.11); 

    const resultData = canvas.toDataURL(mime, quality);
    
    // Liberar memoria interna del canvas
    canvas.width = 0; 
    canvas.height = 0; 
    
    return resultData;
}


async function legacyVariation(sourceImage, originalWidth, originalHeight) {
    // 1. MUTACIÓN DE RELACIÓN DE ASPECTO (Destruye la firma de dimensiones)
    // Alteramos el ancho y el alto de forma asimétrica (+/- 5%)
    const widthWarp = originalWidth * (0.95 + Math.random() * 0.1);
    const heightWarp = originalHeight * (0.95 + Math.random() * 0.1);
    
    const targetCanvas = document.createElement('canvas');
    targetCanvas.width = widthWarp;
    targetCanvas.height = heightWarp;
    const ctx = targetCanvas.getContext('2d');

    // 2. CREACIÓN DE UNA NUEVA ESCENA (Padding dinámico borroso)
    // Llenamos el fondo con la misma imagen pero expandida y muy borrosa.
    // Esto cambia la paleta de colores global y los bordes externos de la foto.
    ctx.filter = 'blur(15px) brightness(70%)';
    ctx.drawImage(sourceImage, -30, -30, widthWarp + 60, heightWarp + 60);
    ctx.filter = 'none';

    // 3. INYECCIÓN DEL OBJETO PRINCIPAL
    ctx.save();
    ctx.translate(widthWarp / 2, heightWarp / 2);

    // Rotación evidente pero comercialmente aceptable (hasta 4 grados)
    const angle = (Math.random() - 0.5) * 8 * (Math.PI / 180);
    ctx.rotate(angle);

    // EL ARMA NUCLEAR: FLIP HORIZONTAL ALEATORIO (50% de probabilidad)
    // *ADVERTENCIA*: Si vendes ropa con letras o pantallas, desactiva esto cambiando a: const flipH = false;
    const flipH = Math.random() > 0.5;
    if (flipH) {
        ctx.scale(-1, 1); 
    }

    // Escala del objeto principal (lo encogemos un poco para que se vea el nuevo fondo)
    const scale = 0.82 + Math.random() * 0.12; // Entre 82% y 94%
    const drawW = originalWidth * scale;
    const drawH = originalHeight * scale;

    // Desplazamiento del centro (Offset)
    const offsetX = (Math.random() - 0.5) * (widthWarp * 0.08);
    const offsetY = (Math.random() - 0.5) * (heightWarp * 0.08);

    // Ajustes de luz y contraste pesados (visibles pero que hacen la foto más atractiva)
    const bri = 90 + Math.random() * 25; // 90% a 115%
    const con = 95 + Math.random() * 20; // 95% a 115%
    ctx.filter = `brightness(${bri}%) contrast(${con}%) drop-shadow(2px 4px 6px rgba(0,0,0,0.3))`;

    ctx.drawImage(sourceImage, -drawW / 2 + offsetX, -drawH / 2 + offsetY, drawW, drawH);
    ctx.restore();

    // 4. RED DE INTERFERENCIA ESTRUCTURAL (Destruye la detección de bordes CNN)
    // Dibuja entre 5 y 15 líneas aleatorias gigantes con un 2% de opacidad.
    // Para el humano parece un reflejo sutil de luz. Para la IA, son bordes físicos.
    ctx.globalAlpha = 0.02;
    ctx.strokeStyle = Math.random() > 0.5 ? '#FFFFFF' : '#000000';
    const linesCount = 5 + Math.floor(Math.random() * 10);
    
    for (let i = 0; i < linesCount; i++) {
        ctx.beginPath();
        ctx.moveTo(Math.random() * widthWarp, Math.random() * heightWarp);
        ctx.lineTo(Math.random() * widthWarp, Math.random() * heightWarp);
        ctx.lineWidth = 1 + Math.random() * 4;
        ctx.stroke();
    }
    ctx.globalAlpha = 1.0;

    // 5. EXPORTACIÓN CON RUIDO DE COMPRESIÓN ORGÁNICA
    const quality = 0.80 + Math.random() * 0.15; // Calidad entre 80% y 95%
    
    return new Promise((resolve) => {
        resolve(targetCanvas.toDataURL('image/jpeg', quality));
    });
}

async function normalizeAssetImage(img, quality, requestedType) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  const wOffset = Math.floor(Math.random() * 3);
  const hOffset = Math.floor(Math.random() * 3);
  const drawW = img.width + wOffset;
  const drawH = img.height + hOffset;
  canvas.width = drawW;
  canvas.height = drawH;

  const brightness = 98 + (Math.random() * 4);
  const contrast = 99 + (Math.random() * 2);
  const saturate = 99 + (Math.random() * 2);
  ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturate}%)`;

  ctx.translate(drawW / 2, drawH / 2);
  const angle = ((Math.random() * 0.2) - 0.1) * (Math.PI / 180);
  ctx.rotate(angle);
  ctx.drawImage(img, -img.width / 2, -img.height / 2, img.width, img.height);
  ctx.rotate(-angle);
  ctx.translate(-drawW / 2, -drawH / 2);
  ctx.filter = 'none';

  ctx.fillStyle = `rgba(${Math.floor(Math.random()*255)}, ${Math.floor(Math.random()*255)}, ${Math.floor(Math.random()*255)}, 0.005)`;
  ctx.fillRect(Math.random() * (drawW / 2), Math.random() * (drawH / 2), 50 + Math.random() * 100, 50 + Math.random() * 100);

  const baseQuality = Math.max(0.85, Math.min(0.95, Number(quality) || 0.92));
  const randomQuality = Math.max(0.85, Math.min(0.98, baseQuality + (Math.random() * 0.05 - 0.02)));
  const type = requestedType === 'image/webp' ? 'image/webp' : 'image/jpeg';
  const ext = type === 'image/webp' ? 'webp' : 'jpg';
  
  return canvas.toDataURL(type, randomQuality);
}
