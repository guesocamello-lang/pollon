function injectDiagnoseMarketplace() {
  const targetUrl = 'https://www.facebook.com/marketplace/create/item';
  if (!location.href.includes('/marketplace/create/item')) {
    location.href = targetUrl;
    return { status: 'navigating', url: location.href };
  }

  const allInputs = [...document.querySelectorAll('input,textarea,select')].filter(el => !el.disabled);
  const textOf = el => [
    el.placeholder,
    el.getAttribute('aria-label'),
    el.name,
    el.id,
    el.closest('label')?.textContent,
    el.closest('div')?.textContent,
  ].filter(Boolean).join(' ').toLowerCase();
  const hasInput = hints => allInputs.some(el => hints.some(h => textOf(el).includes(h.toLowerCase())));
  const buttons = [...document.querySelectorAll('[role="button"],button,a,div[tabindex]')];
  const publishHints = ['next', 'siguiente', 'continue', 'continuar', 'review', 'revisar', 'publish', 'publicar', 'post', 'list item'];
  const publishButtons = buttons.filter(el => {
    const txt = `${el.textContent || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
    return publishHints.some(h => txt.includes(h));
  });
  const categorySamples = [...document.querySelectorAll('[role="option"],li,span,div[tabindex]')]
    .map(el => el.textContent?.trim())
    .filter(txt => txt && txt.length > 2 && txt.length < 45)
    .slice(0, 12);

  return {
    status: 'ok',
    url: location.href,
    isCreateItem: location.href.includes('/marketplace/create/item'),
    title: hasInput(['title', 'titulo', 'título', 'what are you selling', 'que vendes']),
    price: hasInput(['price', 'precio', 'amount', 'monto']),
    category: hasInput(['category', 'categoria', 'categoría']),
    description: hasInput(['description', 'descripcion', 'descripción', 'describe']),
    location: hasInput(['location', 'ubicacion', 'ubicación', 'city', 'ciudad']),
    fileInputs: document.querySelectorAll('input[type="file"]').length,
    publishButtons: publishButtons.length,
    categorySamples,
  };
}

// ══════════════════════════════════════════════════════════════════════════════════
//  INJECTED: Publish - ULTRA SPEED
// ══════════════════════════════════════════════════════════════════════════════════
function injectPublish(entry) {
  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

    function obfuscateText(text) {
    if (!text) return "";
    return text.trim();
  }

  async function waitFor(selector, timeout = 10000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const el = document.querySelector(selector);
      if (el) return el;
      await delay(100);
    }
    return null;
  }

  async function waitForText(texts, timeout = 5000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const found = [...document.querySelectorAll('[role="button"],button,div[tabindex],span,a')]
        .find(el => texts.some(t => {
          const target = t.toLowerCase();
          const txt = el.textContent?.trim().toLowerCase() || '';
          const aria = el.getAttribute('aria-label')?.trim().toLowerCase() || '';
          return txt === target || aria === target || txt.includes(target) || aria.includes(target);
        }));
      if (found) return found;
      await delay(100);
    }
    return null;
  }

  function findBtn(labels) {
    return [...document.querySelectorAll('[role="button"],button,a,div[tabindex]')]
      .find(el => labels.some(l =>
        el.textContent?.trim() === l ||
        el.getAttribute('aria-label') === l ||
        el.getAttribute('aria-label')?.includes(l)
      ));
  }

  async function ensureItemForSaleFlow() {
    const itemLabels = [
      'Item for sale', 'Item for Sale', 'Sell item', 'Create item listing',
      'Articulo en venta', 'Artículo en venta', 'Item en venta', 'Ítem en venta',
      'Crear publicacion de articulo', 'Crear publicación de artículo'
    ];
    const btn = await waitForText(itemLabels, 3000);
    if (!btn) return false;
    btn.click();
    await delay(1000);
    return true;
  }

  function fillReactInput(el, value) {
    if (!el) return false;
    el.focus();

    // Facebook Marketplace usa <textarea>/<input> en algunas versiones y
    // contenteditable/role=textbox en otras (especialmente en español).
    // El setter de HTMLInputElement NO funciona sobre contenteditable.
    if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
      try {
        document.execCommand?.('selectAll', false, null);
        document.execCommand?.('insertText', false, String(value ?? ''));
      } catch {}
      if (normText(el.textContent) !== normText(value)) {
        el.textContent = String(value ?? '');
      }
      el.dispatchEvent(new InputEvent('input', {
        bubbles: true, cancelable: true, inputType: 'insertText', data: String(value ?? '')
      }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }

    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, String(value ?? ''));
    else el.value = String(value ?? '');
    el.dispatchEvent(new InputEvent('input',  { bubbles: true, cancelable: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
    return true;
  }

  function addPublicationNumberToDescription(text, publishSequence = 1) {
    const n = Math.max(1, Math.min(100, Number(publishSequence || 1)));
    const lines = String(text || '').split(/\r?\n/);
    const avoid = /whats\s*app|whatsapp|tel[eé]fono|phone|contact|contacto|📲|☎|2️⃣|3️⃣|4️⃣|5️⃣|6️⃣|7️⃣|8️⃣|9️⃣|0️⃣|1️⃣|\*|•|caracter/i;
    const hasNumber = new RegExp(`\\b${n}\\b`).test(lines.join('\n'));

    if (hasNumber) return lines.join('\n');
    for (let i = 0; i < lines.length; i++) {
      const clean = lines[i].trim();
      if (!clean || avoid.test(clean) || clean.length > 90) continue;
      lines[i] = `${lines[i]} ${n}`;
      return lines.join('\n');
    }

    return `Publicacion ${n}\n\n${lines.join('\n')}`.trim();
  }

  function findInput(hints) {
    const controls = () => [...document.querySelectorAll(
      'input,textarea,[contenteditable="true"],[role="textbox"]'
    )].filter(el => !el.disabled && isVisible(el));

    for (const hint of hints) {
      const wanted = normText(hint);
      let el = controls().find(i => normText(i.getAttribute('placeholder') || '') === wanted);
      if (el) return el;

      el = controls().find(i => normText(i.getAttribute('placeholder') || '').includes(wanted));
      if (el) return el;

      el = controls().find(i => normText(i.getAttribute('aria-label') || '').includes(wanted));
      if (el) return el;

      const spans = [...document.querySelectorAll('span,label,div')].filter(s =>
        isVisible(s) && normText(s.textContent || '') === wanted
      );
      for (const span of spans) {
        const parent = span.closest('div,label,fieldset');
        if (!parent) continue;
        const inp = [...parent.querySelectorAll(
          'input,textarea,[contenteditable="true"],[role="textbox"]'
        )].find(x => !x.disabled && isVisible(x));
        if (inp) return inp;
      }
    }
    return null;
  }

  function normText(value) {
    return String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  }

  function fireKey(el, key) {
    const keyCode = key === 'Enter' ? 13 : key === 'ArrowDown' ? 40 : key === 'Escape' ? 27 : 0;
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key, keyCode, which: keyCode }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key, keyCode, which: keyCode }));
  }

  function clickLikeUser(el) {
    if (!el) return;
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(type => {
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
  }

  function compactOptionText(el) {
    const aria = el.getAttribute('aria-label') || '';
    const text = el.textContent || '';
    return normText(aria || text);
  }

  function optionClickTarget(el) {
    return el.closest?.('[role="option"],[role="menuitem"],[role="radio"],[role="button"],button,li,div[tabindex]') || el;
  }

  function findVisibleOption(labels) {
    const wanted = labels.map(normText).filter(Boolean);
    const optionSelectors = '[role="option"],[role="menuitem"],[role="radio"],[role="listitem"],li,[aria-selected],[aria-checked]';
    const candidates = [...document.querySelectorAll(optionSelectors)]
      .filter(el => isVisible(el) && !el.querySelector?.('input,textarea,select'))
      .map(el => ({ el, text: compactOptionText(el) }))
      .filter(x => x.text && x.text.length <= 120);

    const exact = candidates.find(({ text }) => wanted.some(label => text === label));
    if (exact) return optionClickTarget(exact.el);

    const starts = candidates.find(({ text }) => wanted.some(label => text.startsWith(label)));
    if (starts) return optionClickTarget(starts.el);

    const option = candidates.find(({ text }) => wanted.some(label => text.includes(label)));
    if (option) return optionClickTarget(option.el);

    const fallbackNodes = [...document.querySelectorAll('span,div[tabindex],button,[aria-label]')];
    const fallbackExact = fallbackNodes.find(el => {
      if (!isVisible(el)) return false;
      if (el.querySelector?.('input,textarea,select')) return false;
      const text = compactOptionText(el);
      if (!text || text.length > 100) return false;
      return wanted.some(label => text === label);
    });
    if (fallbackExact) return optionClickTarget(fallbackExact);

    return fallbackNodes.find(el => {
      if (!isVisible(el)) return false;
      if (el.querySelector?.('input,textarea,select')) return false;
      const text = compactOptionText(el);
      if (!text || text.length > 100) return false;
      return wanted.some(label => text.includes(label));
    });
  }

  async function chooseVisibleOption(labels, timeout = 3000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const opt = findVisibleOption(labels);
      if (opt) {
        opt.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(50);
        clickLikeUser(opt);
        await delay(200);
        return true;
      }
      await delay(100);
    }
    return false;
  }

  function findFieldShell(labels) {
    const wanted = labels.map(normText).filter(Boolean);
    const controls = [...document.querySelectorAll(
      'input,textarea,select,[role="combobox"],[role="button"],button,div[tabindex],[aria-label]'
    )].filter(isVisible);

    let direct = controls.find(el => {
      const labelText = normText([
        el.getAttribute('aria-label'),
        el.getAttribute('placeholder'),
        el.getAttribute('name'),
        el.id
      ].filter(Boolean).join(' '));
      return wanted.some(label => labelText.includes(label));
    });
    if (direct) return direct;

    direct = controls.find(el => {
      const text = compactOptionText(el);
      return text && text.length <= 80 && wanted.some(label => text === label || text.includes(label));
    });
    if (direct) return direct;

    const labelNodes = [...document.querySelectorAll('label,span,div')].filter(isVisible);
    for (const labelNode of labelNodes) {
      const text = normText(labelNode.textContent);
      if (!text || text.length > 80) continue;
      if (!wanted.some(label => text === label || text.startsWith(label))) continue;
      let parent = labelNode.closest('label,div,fieldset');
      for (let i = 0; parent && i < 5; i++, parent = parent.parentElement) {
        const control = parent.querySelector('input,textarea,select,[role="combobox"],[role="button"],button,div[tabindex]');
        if (control && isVisible(control)) return control;
      }
    }
    return null;
  }

  function selectNativeOption(fieldLabels, optionLabels) {
    const fields = fieldLabels.map(normText).filter(Boolean);
    const options = optionLabels.map(normText).filter(Boolean);
    const selects = [...document.querySelectorAll('select')].filter(isVisible);

    for (const select of selects) {
      const fieldText = normText([
        select.getAttribute('aria-label'),
        select.getAttribute('name'),
        select.id,
        select.closest('label,div,fieldset')?.textContent
      ].filter(Boolean).join(' '));
      if (fields.length && !fields.some(label => fieldText.includes(label))) continue;

      const opt = [...select.options].find(o => {
        const text = normText(o.textContent || o.label || o.value);
        return options.some(label => text === label || text.includes(label));
      });
      if (!opt) continue;

      select.value = opt.value;
      select.dispatchEvent(new Event('input', { bubbles: true }));
      select.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    return false;
  }

  async function openMenuField(labels) {
    const el = findInput(labels) || findFieldShell(labels);
    if (!el) return null;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await delay(100);
    clickLikeUser(el);
    await delay(200);
    return el;
  }

  async function typeInField(el, value) {
    if (!el) return false;
    const editable = el.matches?.('input,textarea') || el.isContentEditable;
    if (editable) {
      el.click();
      fillReactInput(el, '');
      await delay(50);
      fillReactInput(el, value);
      await delay(200);
      return true;
    }
    const nested = el.querySelector?.('input,textarea,[contenteditable="true"]');
    if (nested) {
      clickLikeUser(nested);
      fillReactInput(nested, '');
      await delay(50);
      fillReactInput(nested, value);
      await delay(200);
      return true;
    }
    return false;
  }

  async function selectMarketplaceOption(fieldLabels, optionLabels, typedValue = '') {
    if (selectNativeOption(fieldLabels, optionLabels)) {
      await delay(150);
      return true;
    }

    const field = await openMenuField(fieldLabels);
    if (!field) return false;
    if (typedValue) await typeInField(field, typedValue);
    await delay(200);
    const picked = await chooseVisibleOption(optionLabels, 4000);
    if (picked) return true;
    fireKey(field, 'Escape');
    await delay(100);
    return false;
  }

  function isEditableField(el) {
    return !!el && isVisible(el) && !el.disabled && el.getAttribute('aria-hidden') !== 'true' &&
      (el.matches?.('input,textarea') || el.isContentEditable);
  }

  function locationText(el) {
    return normText([
      el.getAttribute?.('aria-label'),
      el.getAttribute?.('placeholder'),
      el.getAttribute?.('name'),
      el.id,
      el.textContent
    ].filter(Boolean).join(' '));
  }

  function locationWords() {
    return [
      'location', 'listing location', 'city', 'where', 'located', 'place', 'town', 'zip', 'postal',
      'ubicacion', 'ubicación', 'ciudad', 'localidad', 'lugar', 'donde', 'dónde', 'ubicado', 'ubicada'
    ];
  }

  function findLocationEditable() {
    const labels = locationWords();
    const exact = [...document.querySelectorAll('input,textarea,[contenteditable="true"]')]
      .filter(isEditableField)
      .find(el => labels.some(label => locationText(el).includes(label)));
    if (exact) return exact;

    const fallbackInputs = [...document.querySelectorAll('input:not([type="file"]),textarea,[contenteditable="true"],[role="combobox"]')]
      .filter(isEditableField)
      .filter(el => {
        const text = locationText(el);
        return !['title', 'titulo', 'título', 'price', 'precio', 'description', 'descripcion', 'descripción', 'tag', 'etiqueta']
          .some(blocked => text.includes(blocked));
      });

    return fallbackInputs[fallbackInputs.length - 1] || null;
  }

  function findLocationClickTargets() {
    const labels = locationWords();
    const targets = [];
    const directControls = [...document.querySelectorAll('input,textarea,[contenteditable="true"],[role="combobox"],[role="button"],button,div[tabindex],[aria-label]')]
      .filter(isVisible)
      .filter(el => labels.some(label => locationText(el).includes(label)));
    targets.push(...directControls);

    const labelNodes = [...document.querySelectorAll('label,span,div')]
      .filter(isVisible)
      .filter(el => {
        const text = normText(el.textContent);
        return text && text.length <= 100 && labels.some(label => text === label || text.startsWith(label));
      });

    for (const labelNode of labelNodes) {
      let parent = labelNode.closest('label,div,fieldset');
      for (let i = 0; parent && i < 7; i++, parent = parent.parentElement) {
        const preferred = [...parent.querySelectorAll('input,textarea,[contenteditable="true"],[role="combobox"],[role="button"],button,div[tabindex]')]
          .filter(isVisible)
          .filter(el => el !== labelNode);
        targets.push(...preferred);
      }
    }

    return [...new Set(targets)].filter(el => isVisible(el));
  }

  async function openLocationEditable() {
    let field = findLocationEditable();
    if (field) return field;

    for (const target of findLocationClickTargets()) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await delay(100);
      clickLikeUser(target);
      await delay(300);

      if (isEditableField(document.activeElement)) return document.activeElement;
      field = findLocationEditable();
      if (field) return field;

      const nested = [...(target.querySelectorAll?.('input,textarea,[contenteditable="true"]') || [])].find(isEditableField);
      if (nested) return nested;
    }

    return null;
  }

  function fillLocationEditable(el, value) {
    el.focus();
    clickLikeUser(el);
    if (el.isContentEditable) {
      document.execCommand?.('selectAll', false, null);
      document.execCommand?.('insertText', false, value);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: value }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    el.select?.();
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a', code: 'KeyA', ctrlKey: true }));
    if (setter) setter.call(el, '');
    else el.value = '';
    el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'deleteContentBackward' }));
    for (const ch of String(value)) {
      const nextValue = `${el.value || ''}${ch}`;
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ch }));
      if (setter) setter.call(el, nextValue);
      else el.value = nextValue;
      el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: ch }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: ch }));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: value.slice(-1) || 'a' }));
  }

  function editableHasValue(el, value) {
    const wanted = normText(value);
    const actual = normText(`${el.value || ''} ${el.textContent || ''}`);
    return !!wanted && actual.includes(wanted);
  }

  function locationSuggestionCandidates(input) {
    const selectors = '[role="option"],[role="menuitem"],[role="listitem"],li,[aria-selected]';
    const controlledIds = [
      input.getAttribute('aria-controls'),
      input.getAttribute('aria-owns'),
      input.getAttribute('list')
    ].filter(Boolean);

    const controlled = controlledIds
      .map(id => document.getElementById(id))
      .filter(Boolean)
      .flatMap(box => [...box.querySelectorAll(selectors)]);

    const inputRect = input.getBoundingClientRect();
    const visible = [...new Set([...controlled, ...document.querySelectorAll(selectors)])]
      .filter(el => {
        if (!isVisible(el) || el.querySelector?.('input,textarea,select')) return false;
        const text = compactOptionText(el);
        if (!text || text.length > 160) return false;
        const rect = el.getBoundingClientRect();
        const nearInput = rect.top >= inputRect.top - 80 && rect.top <= inputRect.bottom + 700;
        return controlled.includes(el) || nearInput || el.getAttribute('role') === 'option';
      });

    return visible;
  }

  async function chooseFirstLocationSuggestion(input, timeout = 5000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const first = locationSuggestionCandidates(input)[0];
      if (first) {
        const target = optionClickTarget(first);
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(50);
        clickLikeUser(target);
        await delay(300);
        return true;
      }
      await delay(150);
    }
    return false;
  }

  async function clickFirstLocationSuggestionByPosition(input, timeout = 4000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const rect = input.getBoundingClientRect();
      const xs = [
        rect.left + rect.width / 2,
        rect.left + Math.min(rect.width - 20, 40),
        rect.right - 40
      ].filter(x => x > 0 && x < window.innerWidth);
      const ys = [18, 34, 52, 72, 96, 124]
        .map(offset => rect.bottom + offset)
        .filter(y => y > 0 && y < window.innerHeight);

      for (const y of ys) {
        for (const x of xs) {
          let el = document.elementFromPoint(x, y);
          if (!el || el === input || input.contains?.(el)) continue;
          if (el.closest?.('input,textarea,select')) continue;

          const target = optionClickTarget(el);
          clickLikeUser(target);
          await delay(300);
          return true;
        }
      }
      await delay(150);
    }
    return false;
  }

    async function typeCityAndPickFirst(field, cityText) {
    field.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await delay(100);
    fillLocationEditable(field, cityText);
    await delay(1500); 

    if (await clickFirstLocationSuggestionByPosition(field, 4000)) return true;
    if (await chooseFirstLocationSuggestion(field, 4000)) return true;

    field.focus();
    fireKey(field, 'ArrowDown');
    await delay(500); 
    fireKey(field, 'Enter');
    await delay(500); 
    
    return editableHasValue(field, cityText);
  }

  async function selectLocationOption(city) {
    if (!city) return true;

    const cityText = String(city).trim();
    let field = await openLocationEditable();
    if (field && await typeCityAndPickFirst(field, cityText)) return true;

    for (const target of findLocationClickTargets()) {
      clickLikeUser(target);
      await delay(300);
      field = isEditableField(document.activeElement) ? document.activeElement : findLocationEditable();
      if (field && await typeCityAndPickFirst(field, cityText)) return true;
    }
    return false;
  }

  function categoryAliases(category) {
    const raw = String(category || '').trim();
    const key = normText(raw);
    const map = {
      'electronics': ['Electronics', 'Electrónica', 'Electronica', 'Electrónica y tecnología'],
      'clothing & accessories': ['Clothing & accessories', 'Clothing and accessories', 'Clothing', 'Ropa y accesorios', 'Ropa y complementos'],
      'furniture': ['Furniture', 'Muebles'],
      'home goods': ['Home goods', 'Household', 'Home', 'Hogar', 'Artículos para el hogar', 'Articulos para el hogar', 'Hogar y jardín', 'Hogar y jardin'],
      'toys & games': ['Toys & games', 'Toys', 'Juguetes y juegos', 'Juguetes'],
      'sports & outdoors': ['Sports & outdoors', 'Sporting goods', 'Deportes y actividades al aire libre', 'Deportes y aire libre', 'Deportes'],
      'tools & home improvement': ['Tools & home improvement', 'Tools', 'Herramientas y mejoras del hogar', 'Herramientas'],
      'books, movies & music': ['Books, movies & music', 'Books', 'Libros, películas y música', 'Libros, peliculas y musica', 'Libros'],
      'baby & kids': ['Baby & kids', 'Baby', 'Bebés y niños', 'Bebes y ninos', 'Bebé y niños', 'Bebe y nino'],
      'health & beauty': ['Health & beauty', 'Salud y belleza'],
      'pet supplies': ['Pet supplies', 'Suministros para mascotas', 'Mascotas'],
      'musical instruments': ['Musical instruments', 'Instrumentos musicales'],
      'office supplies': ['Office supplies', 'Suministros de oficina', 'Material de oficina'],
      'garden & outdoor': ['Garden & outdoor', 'Garden', 'Jardín y exterior', 'Jardin y exterior', 'Jardín', 'Jardin'],
      'auto parts': ['Auto parts', 'Vehicle parts', 'Piezas de automóvil', 'Piezas de automovil', 'Autopartes', 'Repuestos de auto'],
      'appliances': ['Appliances', 'Electrodomésticos', 'Electrodomesticos'],
      'arts & crafts': ['Arts & crafts', 'Arts', 'Arte y manualidades', 'Arte y artesanía', 'Arte y manualidades'],
      'bicycles': ['Bicycles', 'Bikes', 'Bicicletas'],
      'cell phones': ['Cell phones', 'Mobile phones', 'Teléfonos celulares', 'Telefonos celulares', 'Teléfonos móviles', 'Telefonos moviles'],
      'jewelry & watches': ['Jewelry & watches', 'Jewelry', 'Joyería y relojes', 'Joyería', 'Joyeria y relojes', 'Joyeria'],
      'video games & consoles': ['Video games & consoles', 'Video games', 'Consoles', 'Videojuegos y consolas', 'Videojuegos'],
      'collectibles': ['Collectibles', 'Coleccionables'],
      'antiques': ['Antiques', 'Antigüedades', 'Antiguedades'],
      'free stuff': ['Free stuff', 'Free', 'Gratis', 'Artículos gratis', 'Articulos gratis'],
      'other': ['Other', 'Miscellaneous', 'Otro', 'Otros', 'Misceláneo', 'Miscelaneo'],
    };
    return map[key] || [raw];
  }

  function conditionAliases(condition) {
    const key = normText(condition);
    const map = {
      'new': ['New', 'Nuevo', 'Nueva', 'Nuevo/a'],
      'nuevo': ['New', 'Nuevo', 'Nueva', 'Nuevo/a'],
      'nueva': ['New', 'Nuevo', 'Nueva', 'Nuevo/a'],
      'like new': ['Like new', 'Como nuevo', 'Como nueva', 'Casi nuevo', 'Casi nueva', 'Usado como nuevo', 'Usado - como nuevo'],
      'como nuevo': ['Like new', 'Como nuevo', 'Como nueva', 'Casi nuevo', 'Casi nueva', 'Usado como nuevo', 'Usado - como nuevo'],
      'good': ['Good', 'Bueno', 'Buena', 'Buen estado', 'Usado - bueno', 'Usado bueno'],
      'bueno': ['Good', 'Bueno', 'Buena', 'Buen estado', 'Usado - bueno', 'Usado bueno'],
      'fair': ['Fair', 'Aceptable', 'Regular', 'Usado - aceptable', 'Usado aceptable'],
      'aceptable': ['Fair', 'Aceptable', 'Regular', 'Usado - aceptable', 'Usado aceptable'],
      'poor': ['Poor', 'Malo', 'Mala', 'Mal estado', 'Usado - malo', 'Usado malo'],
      'malo': ['Poor', 'Malo', 'Mala', 'Mal estado', 'Usado - malo', 'Usado malo'],
    };
    return map[key] || [String(condition || 'Good'), 'Good', 'Bueno', 'Buen estado'];
  }

  async function clearMarketplacePhotos() {
    const removeLabels = ['remove', 'delete', 'quitar', 'eliminar', 'photo', 'foto', 'image', 'imagen'];

    for (let pass = 0; pass < 5; pass++) {
      const removeBtn = [...document.querySelectorAll('button,[role="button"],div[tabindex]')]
        .filter(isVisible)
        .find(el => {
          const aria = normText(el.getAttribute('aria-label') || '');
          const text = normText(`${aria} ${el.textContent || ''}`);
          const looksLikeRemove = removeLabels.some(label => text.includes(label));
          const mentionsMedia = ['photo', 'foto', 'image', 'imagen'].some(label => text.includes(label));
          const ariaMentionsMedia = ['photo', 'foto', 'image', 'imagen'].some(label => aria.includes(label));
          return looksLikeRemove && (mentionsMedia || ariaMentionsMedia);
        });
      if (!removeBtn) break;
      clickLikeUser(removeBtn);
      await delay(100);
    }

    [...document.querySelectorAll('input[type="file"]')]
      .filter(i => !i.disabled && (!i.accept || i.accept.toLowerCase().includes('image')))
      .forEach(input => {
        try { input.value = ''; } catch {}
        if (typeof DataTransfer !== 'undefined') {
          try { input.files = new DataTransfer().files; } catch {}
        }
        input.dispatchEvent(new Event('input', { bubbles:true }));
        input.dispatchEvent(new Event('change', { bubbles:true }));
      });
  }

  function resetImageFileInput(input, dispatch = true) {
    if (!input) return;
    try { input.value = ''; } catch {}
    if (typeof DataTransfer !== 'undefined') {
      try { input.files = new DataTransfer().files; } catch {}
    }
    if (dispatch) {
      input.dispatchEvent(new Event('input', { bubbles:true }));
      input.dispatchEvent(new Event('change', { bubbles:true }));
    }
  }

  function rotatePhotosForListing(photos, startIndex = 0) {
    const list = (photos || []).filter(Boolean);
    if (list.length <= 1) return list;
    const start = Math.abs(Number(startIndex) || 0) % list.length;
    return [...list.slice(start), ...list.slice(0, start)];
  }

  function makeUniquePhotoFilename(ext = 'jpg') {
    const safeExt = String(ext || 'jpg').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'jpg';
    const id = globalThis.crypto?.randomUUID
      ? globalThis.crypto.randomUUID()
      : `${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
    return `apt-photo-${Date.now()}-${id}.${safeExt}`;
  }

  // Convierte nuestra foto Base64 de la Carpeta Virtual a un Archivo Real para Facebook
  function dataUrlToFile(src) {
    try {
      const mime=(String(src).match(/^data:([^;]+);base64,/)||[])[1]||'image/jpeg';
      const ext=mime.includes('png')?'png':mime.includes('webp')?'webp':'jpg';
      return RemoteDOM.file(src,makeUniquePhotoFilename(ext),{type:mime,lastModified:Date.now()-Math.floor(Math.random()*100000000)});
    } catch {return null;}
  }

  async function uploadPhotos(photos, startIndex = 0, publishSequence = 1) {
    // Rescatamos las fotos desde el storage para inyectarlas limpio y rápido
    const storageRes = await chrome.storage.local.get('temp_photos_v7');
    const realPhotos = storageRes.temp_photos_v7 || [];
    
    if (!realPhotos || !realPhotos.length) return 'no-photos';
    await clearMarketplacePhotos();

    const preparedFiles = [];
    const limitPhotos = realPhotos.slice(0, 10);
    
    for (const src of rotatePhotosForListing(limitPhotos, startIndex)) {
      const file = dataUrlToFile(src);
      if (file) preparedFiles.push(file);
    }
    
    if (!preparedFiles.length) return 'photo-data-invalid';

    const input = [...document.querySelectorAll('input[type="file"]')]
      .find(i => !i.disabled && (!i.accept || i.accept.toLowerCase().includes('image')));
    if (!input || typeof DataTransfer === 'undefined') return 'photo-input-not-found';

    const dt = new DataTransfer();
    preparedFiles.forEach(file => dt.items.add(file));
    resetImageFileInput(input, false);
    input.files = dt.files;
    input.dispatchEvent(new Event('input', { bubbles:true }));
    input.dispatchEvent(new Event('change', { bubbles:true }));
    await delay(1000); // Reducido a 1s para ganar velocidad sin romper la carga
    return 'photos-ok';
  }

  return new Promise(async (resolve, reject) => {
    try {
      const targetUrl = 'https://www.facebook.com/marketplace/create/item';
      if (!window.location.href.includes('/create/item')) {
        window.location.href = targetUrl;
        return resolve('navigating');
      }

      let titleEl = await waitFor(
        'input[placeholder="Title"], input[placeholder="Titulo"], input[placeholder="title"]',
        3000 // Reducido para no generar un retraso enorme en el vacío si FB falla
      );
      if (!titleEl) titleEl = findInput(['Title', 'Titulo', 'Título', 'What are you selling', 'Que vendes', '¿Qué vendes?']);

      if (!titleEl) {
        const enteredItemFlow = await ensureItemForSaleFlow();
        if (enteredItemFlow) {
          titleEl = await waitFor(
            'input[placeholder="Title"], input[placeholder="Titulo"], input[placeholder="title"]',
            5000
          );
          if (!titleEl) titleEl = findInput(['Title', 'Titulo', 'Título', 'What are you selling', 'Que vendes', '¿Qué vendes?']);
        }
      }

      if (!titleEl) return resolve('form-not-found');

      await delay(200);

      titleEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await delay(100);
      titleEl.click();
      fillReactInput(titleEl, '');
      await delay(50);
      
      let tituloMutado = obfuscateText(entry.title);
      fillReactInput(titleEl, tituloMutado);

      // Fotos: Facebook puede tardar en montar el input. Reintentamos y no seguimos
      // hasta que la carga haya sido enviada correctamente.
      let photoStatus = await uploadPhotos(entry.photos, entry.photoStartIndex || 0, entry.publishSequence || 1);
      if (photoStatus !== 'photos-ok') {
        await delay(700);
        photoStatus = await uploadPhotos(entry.photos, entry.photoStartIndex || 0, entry.publishSequence || 1);
      }
      if (entry.photos?.length && photoStatus !== 'photos-ok') return resolve(photoStatus);

      await delay(500);
      const priceEl = findInput(['Price', 'Precio', 'price', 'precio', 'Amount', 'Monto']);
      if (!priceEl) return resolve('price-not-found');
      priceEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      priceEl.click();
      fillReactInput(priceEl, '');
      fillReactInput(priceEl, String(entry.price));
      await delay(150);
      if (normText(priceEl.value) !== normText(String(entry.price))) {
        fillReactInput(priceEl, String(entry.price));
      }

      await delay(100);
      // Categoría: acepta tanto el valor interno en inglés como uno guardado en español.
      const categoryOk = await selectMarketplaceOption(
        ['Category', 'category', 'Categoria', 'Categoría', 'categoria', 'categoría'],
        categoryAliases(entry.category),
        ''
      );
      if (!categoryOk) return resolve('category-not-found');

      await delay(150);
      // Estado/condición: también se adapta al idioma visible en Marketplace.
      const condTexts = conditionAliases(entry.condition);
      let conditionOk = false;

      const condSelect = document.querySelector(
        'select[aria-label*="condition" i], select[aria-label*="condicion" i], select[aria-label*="condición" i], select[aria-label*="Condition" i], select[aria-label*="estado" i]'
      );
      if (condSelect) {
        const condOpt = [...condSelect.options].find(o =>
          condTexts.some(c => o.text.toLowerCase().includes(c.toLowerCase()))
        );
        if (condOpt) {
          condSelect.value = condOpt.value;
          condSelect.dispatchEvent(new Event('change', { bubbles: true }));
          conditionOk = true;
        }
      } else {
        conditionOk = await selectMarketplaceOption(
          ['Condition', 'condition', 'Condicion', 'Condición', 'condicion', 'condición', 'Estado', 'estado', 'Estado del artículo', 'Estado del articulo', 'Item condition'],
          condTexts
        );
      }
      if (!conditionOk) return resolve('condition-not-found');

      await delay(100);
      const descEl = findInput(['Description', 'Descripcion', 'Descripcion', 'description', 'descripcion', 'descripcion', 'Describe']);
      if (descEl) {
        descEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        descEl.click();
        const descText = addPublicationNumberToDescription(
          entry.desc || `${entry.title} - ${entry.condition} - $${entry.price}`,
          entry.publishSequence || 1
        );
        
        let descMutada = obfuscateText(descText);
        fillReactInput(descEl, descMutada);
        await delay(150);
        // Si Facebook montó un textbox contenteditable, comprobamos que el
        // contenido realmente entró antes de continuar.
        if (normText(descEl.textContent || descEl.value || '') !== normText(descMutada)) {
          fillReactInput(descEl, descMutada);
          await delay(150);
        }
      }

      if (entry.assignedCity) {
        await delay(100);
        const locationOk = await selectLocationOption(entry.assignedCity);
        if (!locationOk) return resolve('location-not-found');
      }

      if (entry.tags) {
        await delay(100);
        const tagEl = findInput(['Tags', 'Tag', 'Etiqueta', 'Keywords', 'tag', 'keyword']);
        if (tagEl) {
          const tags = entry.tags.split(',').map(t => t.trim()).filter(Boolean).slice(0, 3);
          for (const tag of tags) {
            tagEl.click();
            fillReactInput(tagEl, tag);
            await delay(100);
            tagEl.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13 }));
            await delay(100);
          }
        }
      }

      if (entry.offers === 'yes') {
        await delay(100);
        const offerToggle = [...document.querySelectorAll('[role="switch"],input[type="checkbox"]')]
          .find(el =>
            el.getAttribute('aria-label')?.toLowerCase().includes('offer') ||
            el.getAttribute('aria-label')?.toLowerCase().includes('oferta')
          );
        if (offerToggle && offerToggle.getAttribute('aria-checked') !== 'true') {
          offerToggle.click();
        }
      }

      await delay(300);

      if (entry.previewOnly) {
        return resolve('ready-to-publish');
      }

      const publishLabels = ['Publish', 'Publicar', 'Post', 'Publicar ahora', 'List item', 'Crear publicacion'];
const nextLabels = ['Next', 'Siguiente', 'Continue', 'Continuar', 'Review', 'Revisar', ...publishLabels];

for (let step = 0; step < 6; step++) {
  let btn = null;
  let isDisabled = true;
  const startTime = Date.now();

  // Bucle de micro-monitoreo: revisa a máxima velocidad (cada 50ms)
  while (Date.now() - startTime < 3500) { // Tiempo límite de 3.5 segundos por pantalla
    btn = findBtn(nextLabels);
    if (btn) {
      isDisabled = btn.getAttribute('aria-disabled') === 'true' || btn.disabled;
      if (!isDisabled) break; // ¡Botón listo! Rompe el bucle al instante sin esperar más
    }
    // Pausa imperceptible de 50ms para evitar que el navegador se congele
    await new Promise(r => setTimeout(r, 50)); 
  }

  // Si no se encuentra el botón o sigue bloqueado tras el tiempo límite, el formulario está incompleto
  if (!btn || isDisabled) return resolve('form-incomplete');

  const txt = btn.textContent?.trim();
  btn.click();

  // Mini pausa de 150ms sólo para que la interfaz asimile el click antes de evaluar el siguiente paso
  await new Promise(r => setTimeout(r, 150));
  if (publishLabels.includes(txt)) break;
}

      resolve('ok');
    } catch (err) {
      reject(err);
    }
  });
}

function injectRelist({ delay: delayMs, city }) {
  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

  function findBtn(labels) {
    return [...document.querySelectorAll('[role="button"],button,a')]
      .find(el => labels.some(l =>
        el.textContent?.trim() === l ||
        el.getAttribute('aria-label') === l ||
        el.getAttribute('aria-label')?.toLowerCase().includes(l.toLowerCase())
      ));
  }

  return new Promise(async (resolve, reject) => {
    try {
      const sellerUrl = 'https://www.facebook.com/marketplace/you/selling';
      if (!window.location.href.includes('/you/selling')) {
        window.location.href = sellerUrl;
        await delay(3000);
        return resolve('navigating');
      }

      await delay(2000);

      const listingCards = [...document.querySelectorAll('[role="main"] a[href*="/item/"]')];
      if (listingCards.length === 0) return resolve('no listings found');

      let relisted = 0;
      const MAX_RELIST = 5; 

      for (let i = 0; i < Math.min(listingCards.length, MAX_RELIST); i++) {
        const card = listingCards[i];
        const parent = card.closest('div[class]') || card.parentElement?.parentElement;
        if (!parent) continue;

        const menuBtn = parent.querySelector('[aria-label*="More options" i], [aria-label*="mas opciones" i], [aria-label*="Edit" i]')
          || [...parent.querySelectorAll('[role="button"]')].find(b =>
              b.getAttribute('aria-label')?.toLowerCase().includes('option') ||
              b.textContent?.trim() === 'â€¦' || b.textContent?.trim() === 'â€¢â€¢â€¢'
            );

        if (menuBtn) {
          menuBtn.click();
          await delay(800);

          const renewBtn = findBtn(['Renew listing', 'Renovar anuncio', 'Refresh listing', 'Actualizar']);
          const editBtn  = findBtn(['Edit listing', 'Editar anuncio', 'Edit']);

          if (renewBtn) {
            renewBtn.click();
            await delay(1200);
            relisted++;
          } else if (editBtn) {
            editBtn.click();
            await delay(2000);

            const descEl = document.querySelector('[aria-label*="description" i], [aria-label*="descripcion" i]');
            if (descEl) {
              const cur = descEl.value || descEl.textContent || '';
              const trimmed = cur.trimEnd();
              const nv = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set
                      || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
              if (nv) { nv.call(descEl, trimmed + ' '); descEl.dispatchEvent(new Event('input', { bubbles:true })); }
              await delay(400);
            }

            if (city) {
              const locEl = document.querySelector('[aria-label*="location" i], [aria-label*="ciudad" i], [aria-label*="ubicacion" i]');
              if (locEl) {
                locEl.click(); await delay(300);
                const nv = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                if (nv) { nv.call(locEl, city); locEl.dispatchEvent(new Event('input', { bubbles:true })); }
                await delay(800);
                const opt = [...document.querySelectorAll('[role="option"]')]
                  .find(el => el.textContent?.includes(city.split(',')[0]));
                if (opt) { opt.click(); await delay(500); }
              }
            }

            const saveBtn = findBtn(['Save','Guardar','Update','Actualizar','Publish','Publicar']);
            if (saveBtn) { saveBtn.click(); await delay(1000); relisted++; }
          }
        }
        await delay(delayMs * 0.5 || 1000);
      }
      resolve(relisted);
    } catch(err) {
      reject(err);
    }
  });
}

function injectDeleteListings({ qty, delay: delayMs }) {
  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

  function findBtn(labels) {
    return [...document.querySelectorAll('[role="button"],button,a,div[tabindex]')]
      .find(el => labels.some(l =>
        el.textContent?.trim() === l ||
        el.getAttribute('aria-label') === l ||
        el.getAttribute('aria-label')?.toLowerCase().includes(l.toLowerCase())
      ));
  }

  return new Promise(async (resolve, reject) => {
    try {
      if (!window.location.href.includes('/you/selling')) {
        window.location.href = 'https://www.facebook.com/marketplace/you/selling';
        await delay(3500);
        return resolve(0);
      }

      await delay(2000);
      let deleted = 0;

      for (let attempt = 0; attempt < qty; attempt++) {
        const cards = [...document.querySelectorAll('[role="main"] [data-testid*="listing"], [role="main"] a[href*="/item/"]')];
        const card  = cards[0];
        if (!card) break;

        const parent = card.closest('div[data-testid]') || card.closest('div[class]') || card.parentElement?.parentElement;
        if (!parent) break;

        const menuBtn = parent.querySelector('[aria-label*="More options" i], [aria-label*="mas opciones" i]')
          || [...parent.querySelectorAll('[role="button"]')].find(b =>
              b.getAttribute('aria-label')?.toLowerCase().includes('option') ||
              b.textContent?.includes('â€¦') || b.textContent?.includes('â€¢â€¢â€¢')
            );

        if (!menuBtn) { await delay(500); continue; }
        menuBtn.click();
        await delay(800);

        const deleteBtn = findBtn(['Delete listing','Eliminar anuncio','Delete','Eliminar','Remove','Quitar']);
        if (!deleteBtn) {
          document.body.click();
          await delay(400);
          break;
        }

        deleteBtn.click();
        await delay(800);

        const confirmBtn = findBtn(['Delete','Eliminar','Confirm','Confirmar','Yes','Si']);
        if (confirmBtn) {
          confirmBtn.click();
          await delay(1000);
          deleted++;
        } else {
          deleted++;
          await delay(800);
        }

        await delay(delayMs * 0.4 || 1000);
      }
      resolve(deleted);
    } catch(err) {
      reject(err);
    }
  });
}

