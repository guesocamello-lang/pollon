import http from 'node:http';
import {readFileSync} from 'node:fs';
import {timingSafeEqual} from 'node:crypto';
import {Store,fail,hash} from './store.mjs';
import {startEngine,stopEngine,photo,ai} from './engine.mjs';
import {Jobs} from './jobs.mjs';
const jobs=new Jobs();
const adminToken=process.env.ADMIN_TOKEN||'';
if(!/^[a-f0-9]{64}$/.test(adminToken)) throw new Error('ADMIN_TOKEN debe tener 64 caracteres hexadecimales aleatorios. Ejecuta setup.mjs.');
const publicURL=process.env.PUBLIC_URL||'http://127.0.0.1:3000';
const store=new Store(process.env.DB_PATH||'./data/licenses.sqlite');
const dailyLimit=Number(process.env.DAILY_LIMIT||1000);
if(!Number.isSafeInteger(dailyLimit)||dailyLimit<1) throw new Error('DAILY_LIMIT inválido.');
const files=new Map([['/', ['text/html; charset=utf-8','admin/index.html']],['/admin.js',['text/javascript; charset=utf-8','admin/admin.js']]]);
const buckets=new Map();let busy=false;
function throttle(key,max){
  const now=Date.now();let b=buckets.get(key);
  if(!b||now-b.at>=60000){b={at:now,n:0};buckets.set(key,b);}
  if(++b.n>max) fail(429,'Demasiadas solicitudes. Espera un minuto.');
}
const cleanup=setInterval(()=>{for(const [k,v] of buckets)if(Date.now()-v.at>60000)buckets.delete(k);},60000);cleanup.unref();
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));}
async function json(req,limit){
  if(!(req.headers['content-type']||'').startsWith('application/json')) fail(415,'Se requiere JSON.');
  if(Number(req.headers['content-length'])>limit) fail(413,'Solicitud demasiado grande.');
  let size=0;const chunks=[];
  for await(const c of req){size+=c.length;if(size>limit) fail(413,'Solicitud demasiado grande.');chunks.push(c);}
  try {const obj=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(!obj||Array.isArray(obj)||typeof obj!=='object') throw 0;return obj;}
  catch{fail(400,'JSON inválido.');}
}
function bearer(req){return /^Bearer ([A-Za-z0-9_-]+)$/.exec(req.headers.authorization||'')?.[1]||'';}
await startEngine();
const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  try {
    const path=new URL(req.url,'http://localhost').pathname;
    // Caddy overwrites X-Forwarded-For. The API port must remain private.
    const ip=process.env.TRUST_PROXY==='true' ? String(req.headers['x-forwarded-for']||req.socket.remoteAddress).split(',').at(-1).trim() : req.socket.remoteAddress;
    throttle((path==='/v1/jobs/step'?'step-ip:':'ip:')+ip,path==='/v1/jobs/step'?60000:600);
    if(req.method==='GET'&&path==='/health') return send(res,200,{ok:true,version:'7.3.0-creator'});
    if(req.method==='GET'&&files.has(path)){
      const [type,file]=files.get(path);res.writeHead(200,{'Content-Type':type});return res.end(readFileSync(new URL(file,import.meta.url)));
    }
    if(req.method!=='POST') fail(404,'No encontrado.');
    const origin=req.headers.origin;
    const requestOrigin = `${req.headers['x-forwarded-proto']||'http'}://${req.headers.host}`;
    if(origin && origin!==publicURL && origin!==requestOrigin && !/^chrome-extension:\/\/[a-p]{32}$/.test(origin)) fail(403,'Origen no permitido.');
    if(path.startsWith('/admin/')){
      throttle('admin:'+ip,30);
      if(!timingSafeEqual(Buffer.from(hash(bearer(req))),Buffer.from(hash(adminToken)))) fail(401,'Acceso de administrador no válido.');
      const data=await json(req,16384);
      if(path==='/admin/list') return send(res,200,{licenses:store.list()});
      if(path==='/admin/create') return send(res,200,store.create(data));
      if(path==='/admin/update') {const result=store.update(data);if(['revoke','reset-devices'].includes(data.action))jobs.cancelOwner(data.id);return send(res,200,result);}
      fail(404,'No encontrado.');
    }
    if(path==='/v1/activate'){
      throttle('activate:'+ip,20);
      const data=await json(req,4096);return send(res,200,store.activate(data.code,data.device));
    }
    const token=bearer(req),license=store.authorize(token);
    throttle((path==='/v1/jobs/step'?'step-license:':'license:')+license.id,path==='/v1/jobs/step'?12000:600);
    if(path==='/v1/status'){await json(req,4096);return send(res,200,{license:store.public(license)});}
    if(path.startsWith('/v1/jobs/')){
      const data=await json(req,5*1024*1024);let result;
      if(path==='/v1/jobs/start') {store.consume(license.id,dailyLimit);result=jobs.start(license.id,data.method,data.args);}
      else if(path==='/v1/jobs/step')result=await jobs.step(license.id,data.job,data.ack);
      else if(path==='/v1/jobs/cancel')result=jobs.cancel(license.id,data.job);
      else fail(404,'No encontrado.');
      store.authorize(token);
      return send(res,200,result);
    }
    if(!['/v1/photo','/v1/ai'].includes(path)) fail(404,'No encontrado.');
    if(busy) fail(503,'El servidor está procesando otro trabajo. Inténtalo nuevamente.');
    busy=true;
    try {
      const data=await json(req,path==='/v1/photo'?25*1024*1024:65536);
      store.authorize(token);store.consume(license.id,dailyLimit);
      const result=path==='/v1/photo'?await photo(data):await ai(data);
      store.authorize(token); // Revocation/expiry while processing also blocks delivery.
      return send(res,200,result);
    } finally{busy=false;}
  }catch(e){if(!res.headersSent)send(res,e.status||500,{error:e.status?e.message:'Error interno del servicio.'});else res.end();}
});
server.requestTimeout=120000;server.headersTimeout=15000;server.maxRequestsPerSocket=100;
server.listen(Number(process.env.PORT||3000),process.env.HOST||'0.0.0.0',()=>console.log('Servicio privado listo.'));
async function shutdown(){server.close();jobs.close();await stopEngine();store.db.close();process.exit(0);}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
