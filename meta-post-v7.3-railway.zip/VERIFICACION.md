# Verificación y alcance — Meta Post 7.3.0

Esta entrega sustituye los ZIP 7.2.0 de la primera separación. Se conserva el ZIP original recibido sin modificar.

## Cambio esencial

El ZIP cliente ya no contiene las funciones de diagnóstico, publicación, renovación y borrado de Facebook. Están en `private/browser-engine.js` del servidor. El cliente contiene interfaz, gestión local de datos y un puente DOM genérico con una lista limitada de operaciones. Las decisiones y la siguiente acción se calculan en el servidor; no se envía código JavaScript para evaluar ni un flujo completo descargable.

Eliminar la pantalla de licencia o forzar `licenseActive` no proporciona el motor ni permite iniciar trabajos con una licencia revocada. La interfaz y los datos locales continúan utilizables. No se promete que nadie pueda reconstruir un sustituto observando las acciones durante un acceso autorizado; el navegador del cliente siempre está bajo su control.

## Pruebas realizadas

- Sintaxis de los scripts del cliente y módulos del servidor.
- Activación válida/inválida, sesiones vencidas, licencias vencidas, límites de instalaciones, revocación, ampliación de plazo y restablecimiento de instalaciones.
- Rechazo de administrador sin credencial, orígenes web ajenos y trabajos sin autorización.
- Los motores privados y `.env` no son descargables mediante las rutas HTTP del servicio.
- Procesamiento real de imágenes en los tres modos y circuito extensión → proceso oculto → servidor → IndexedDB.
- Conexión y activación desde una extensión cargada en un perfil temporal de Chromium.
- Motor de diagnóstico ejecutado en el servidor sobre una página sintética, presentada localmente en una URL de prueba de Marketplace.
- Vista previa: título, precio, categoría, condición, ciudad y foto cargados; no se pulsa Publicar.
- Publicación: el motor remoto completa el formulario sintético y pulsa su botón de prueba.
- Renovación y borrado sobre anuncios sintéticos: los resultados y contadores se verifican, sin tocar anuncios reales.
- Revocación durante una operación: el trabajo se interrumpe antes de publicar en la página de prueba.
- Se fuerza la licencia local a activa y se elimina visualmente el bloqueo después de revocar; el servidor sigue rechazando el trabajo.
- Comparación de archivos: se conservan los identificadores de la interfaz y las funciones originales, distribuidas entre cliente y servidor. Las rutinas de diagnóstico, renovación y borrado mantienen el código original. La publicación conserva su lógica, adaptando la conversión de fotos a una operación local genérica para no reenviar sus píxeles durante cada paso.
- El cliente no contiene las tablas de categorías, las funciones de selección de campos ni el publicador privado. Tampoco contiene credenciales de administración.

## Qué no está probado todavía

- Despliegue Docker/Linux, dominio público y emisión de HTTPS: no había Docker disponible en el entorno de preparación.
- Uso con la cuenta real y los formularios actuales de Facebook. Las pruebas usan formularios simulados; no se crearon, renovaron ni borraron anuncios reales.
- Rendimiento con latencia de internet y varios clientes, y recuperación de copias de seguridad en el VPS.
- Llamadas de IA con facturación real. No se usó una clave ni se generó gasto.

La ejecución de prueba fue Node 24 y Chromium en Windows. El contenedor utiliza Playwright 1.63.0 y descarga su Chromium correspondiente. No equivale a una auditoría independiente de seguridad ni a certificar todos los flujos de Facebook. Antes de entregar a terceros, prueba un artículo propio en vista previa en el alojamiento definitivo.

## Control del propietario y límites

- Revocar desde el panel cancela los trabajos activos de esa licencia y bloquea nuevas órdenes.
- Apagar el servicio impide recibir nuevas decisiones. Una acción ya enviada o ejecutada en el navegador puede completarse; no existe reversión automática de acciones en Facebook.
- Se conserva el límite de 10 borrados por operación de la versión original, también validado al crear el trabajo en el servidor.
- Una instalación es un identificador de navegador, no una prueba física del equipo. Un cliente modificado puede copiar identificador y credenciales; no se promete bloqueo absoluto de cuentas compartidas.
- La interfaz, los datos, los archivos generados y las acciones observadas siguen en manos del destinatario. La protección consiste en no entregar el motor, no en hacer imposible observar el navegador.
- El servidor recibe datos del artículo y los fragmentos/atributos de la página que consulta el motor. No solicita cookies ni contraseña de Facebook. Consulta las condiciones y límites operativos en la guía de alojamiento.
