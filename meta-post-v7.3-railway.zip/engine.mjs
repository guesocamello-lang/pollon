import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {chromium} from 'playwright';
import {fail} from './store.mjs';
const photoCode=readFileSync(new URL('./private/photo-engine.js',import.meta.url),'utf8');
const aiCode=readFileSync(new URL('./private/ai-engine.js',import.meta.url),'utf8');
let browser;
export async function startEngine(){
  browser=await chromium.launch({headless:true,chromiumSandbox:process.env.CHROMIUM_SANDBOX==='true',...(process.env.CHROMIUM_EXECUTABLE?{executablePath:process.env.CHROMIUM_EXECUTABLE}:{})});
}
export async function stopEngine(){await browser?.close();}
export async function photo(body){
  const {photo:input,variant='motor',index=0,total=1,quality=0.92,format='image/jpeg'}=body;
  if(typeof input!=='string'||input.length>24*1024*1024||!/^data:image\/(png|jpeg|webp|gif|bmp|avif);base64,[A-Za-z0-9+/=\r\n]+$/.test(input)) fail(422,'Foto inválida: utiliza una imagen de hasta 18 MB.');
  if(!['motor','legacy','asset'].includes(variant)||!Number.isInteger(index)||index<0||!Number.isFinite(quality)) fail(400,'Parámetros inválidos.');
  const ctx=await browser.newContext({serviceWorkers:'block'});
  await ctx.route('**/*',route=>route.abort());
  const timer=setTimeout(()=>ctx.close().catch(()=>{}),60000);
  try {
    const page=await ctx.newPage();
    await page.addScriptTag({content:photoCode});
    const result=await page.evaluate(async ({input,variant,index,total,quality,format})=>{
      const img=new Image();
      await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error('Imagen no decodificable'));img.src=input;});
      if(!img.width||!img.height||img.width*img.height>40000000) throw new Error('La imagen supera 40 megapíxeles.');
      if(variant==='asset') return normalizeAssetImage(img,quality,format);
      if(variant==='legacy') return legacyVariation(img,img.width,img.height);
      return createExtremeVariation(img,index,total);
    },{input,variant,index,total,quality,format});
    return {photo:result};
  } catch(e){fail(422,'No se pudo procesar la imagen (formato, dimensiones o tiempo límite).');}
  finally {clearTimeout(timer);await ctx.close();}
}
const methods=new Set(['_ask','_json','generateTitleVariants','improveDescription','suggestPrice','analyzePublishError','generateItemFromText']);
export async function ai({method,apiKey,args}){
  if(!methods.has(method)||!Array.isArray(args)||args.length>5) fail(400,'Función de IA inválida.');
  const key=apiKey||process.env.ANTHROPIC_API_KEY;
  if(typeof key!=='string'||key.length<10||key.length>512) fail(400,'Configura una clave de IA válida.');
  const window={};
  const sandbox=vm.createContext({window,fetch:(_url,options)=>fetch('https://api.anthropic.com/v1/messages',{...options,signal:AbortSignal.timeout(60000),redirect:'error'})});
  // Only owner-supplied code is evaluated; client input is passed as data.
  vm.runInContext(aiCode,sandbox,{timeout:1000});
  try{return {result:await window.ai[method](key,...args)};}
  catch{fail(502,'No se pudo completar la consulta de IA. Revisa la clave, el saldo y el servicio.');}
}
