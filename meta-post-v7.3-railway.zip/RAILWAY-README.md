# Meta Post v7.3 — Railway

This server is prepared for Railway deployment. The client extension remains separate.

## Railway setup
1. Push the contents of this folder to the root of a private GitHub repository.
2. In Railway, create a project from that GitHub repository.
3. Railway will build the included Dockerfile.
4. Add a Railway Volume mounted at `/app/data` so licenses persist across redeploys.
5. Add variables: `ADMIN_TOKEN` (64 lowercase hex chars), `DB_PATH=/app/data/licenses.sqlite`, `TRUST_PROXY=true`, `DAILY_LIMIT=1000`. Optionally add `ANTHROPIC_API_KEY`.
6. Generate a public domain in Railway. The service listens on Railway's `PORT` automatically.
7. Open the generated domain; `/health` should return JSON with `ok: true`.

Do not upload the server code to clients.
